package com.cardgame.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;

public final class DuelView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DuelEngine game = new DuelEngine();
    private final Bitmap field;
    private final Bitmap cover;
    private final Bitmap target;
    private final Bitmap attackIcon;
    private final Bitmap chainIcon;
    private final Bitmap actIcon;
    private final Bitmap negatedIcon;

    public DuelView(Context context) {
        super(context);
        setKeepScreenOn(true);
        field = load(context, R.drawable.field);
        cover = load(context, R.drawable.cover);
        target = load(context, R.drawable.target);
        attackIcon = load(context, R.drawable.attack);
        chainIcon = load(context, R.drawable.chain);
        actIcon = load(context, R.drawable.act);
        negatedIcon = load(context, R.drawable.negated);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.5f);
    }

    private Bitmap load(Context c, int id) { return BitmapFactory.decodeResource(c.getResources(), id); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        final float w = getWidth(), h = getHeight();
        c.drawColor(Color.rgb(6, 10, 14));

        // EDOPro-inspired field texture used as a visual layer, not as the game engine.
        if (field != null) c.drawBitmap(field, null, new RectF(0, h * .19f, w, h * .81f), p);
        overlay(c, 0, 0, w, h, 0x99060A0E);

        drawHeader(c, w, h);
        drawZones(c, w, h);
        drawHand(c, w, h);
        drawDecks(c, w, h);
        drawMessage(c, w, h);
        drawBottomBar(c, w, h);
    }

    private void drawHeader(Canvas c, float w, float h) {
        text(c, "CARDGAME V2", 18, 28, 22, Color.WHITE);
        text(c, "OPONENTE", 18, 52, 12, 0xFF9AA8B5);
        textRight(c, "LP " + game.ai.lp, w - 18, 34, 22, 0xFFE8EEF3);
        text(c, "TU", 18, h - 26, 12, 0xFF9AA8B5);
        textRight(c, "LP " + game.you.lp, w - 18, h - 25, 22, 0xFFE8EEF3);
        bar(c, 18, 58, w - 18, 64, game.ai.lp / 8000f, 0xFF6C8396);
        bar(c, 18, h - 58, w - 18, h - 52, game.you.lp / 8000f, 0xFF6C8396);
    }

    private void drawZones(Canvas c, float w, float h) {
        float top = h * .20f, mid = h * .50f, bottom = h * .80f;
        // five-slot monster rows, scaled to screen.
        for (int i = 0; i < 5; i++) {
            float x = w * .18f + i * w * .125f;
            slot(c, x, top, w * .105f, h * .25f);
            slot(c, x, mid, w * .105f, h * .25f);
        }
        drawFieldCards(c, game.ai.field, top, w);
        drawFieldCards(c, game.you.field, mid, w);
        text(c, "OPPONENT FIELD", 20, top - 8, 11, 0xFF9AA8B5);
        text(c, "YOUR FIELD", 20, mid - 8, 11, 0xFF9AA8B5);
    }

    private void drawFieldCards(Canvas c, List<Card> cards, float y, float w) {
        for (int i = 0; i < cards.size() && i < 5; i++) {
            float x = w * .18f + i * w * .125f;
            drawCard(c, cards.get(i), x + 4, y + 4, w * .097f, getHeight() * .22f, false);
        }
    }

    private void drawHand(Canvas c, float w, float h) {
        int n = Math.min(game.you.hand.size(), 7);
        if (n == 0) return;
        float cw = Math.min(w * .095f, 105f);
        float gap = Math.min(cw * .52f, 42f);
        float total = cw + (n - 1) * gap;
        float start = (w - total) / 2f;
        for (int i = 0; i < n; i++) {
            float x = start + i * gap;
            drawCard(c, game.you.hand.get(i), x, h * .805f, cw, h * .17f, true);
        }
    }

    private void drawDecks(Canvas c, float w, float h) {
        float cw = w * .075f, ch = h * .15f;
        if (cover != null) {
            c.drawBitmap(cover, null, new RectF(25, h * .29f, 25 + cw, h * .29f + ch), p);
            c.drawBitmap(cover, null, new RectF(w - 25 - cw, h * .29f, w - 25, h * .29f + ch), p);
        }
        text(c, "DECK", 30, h * .29f + ch + 16, 10, 0xFF9AA8B5);
        textRight(c, "GY", w - 30, h * .29f + ch + 16, 10, 0xFF9AA8B5);
        if (game.selected != null && target != null) {
            c.drawBitmap(target, null, new RectF(w - 62, h * .53f, w - 28, h * .53f + 34), p);
        }
    }

    private void drawMessage(Canvas c, float w, float h) {
        round(c, 18, h * .66f, w - 18, h * .72f, 0xCC0A1017, 0x665F7182);
        text(c, game.message, 32, h * .695f, 14, 0xFFE6EDF3);
        textRight(c, phaseName(), w - 32, h * .695f, 12, 0xFF9FB4C7);
    }

    private String phaseName() {
        switch (game.phase) {
            case DRAW: return "DRAW PHASE";
            case BATTLE: return "BATTLE PHASE";
            case END: return "END PHASE";
            default: return "MAIN PHASE";
        }
    }

    private void drawBottomBar(Canvas c, float w, float h) {
        float y = h - 48;
        action(c, 18, y, 115, h - 8, "SUMMON", actIcon, 0xFF385B77);
        action(c, 122, y, 219, h - 8, "BATTLE", attackIcon, 0xFF385B77);
        action(c, 226, y, 340, h - 8, "ATTACK", chainIcon, 0xFF385B77);
        action(c, w - 125, y, w - 18, h - 8, "END", negatedIcon, 0xFF3E4B57);
    }

    private void action(Canvas c, float l, float t, float r, float b, String label, Bitmap icon, int color) {
        round(c, l, t, r, b, color, 0x8890A5B8);
        if (icon != null) c.drawBitmap(icon, null, new RectF(l + 6, t + 6, l + 34, b - 6), p);
        text(c, label, l + 40, t + 25, 11, Color.WHITE);
    }

    private void drawCard(Canvas c, Card card, float x, float y, float cw, float ch, boolean hand) {
        round(c, x, y, x + cw, y + ch, hand ? 0xEE263543 : 0xEE17232E, 0xAA8EA2B5);
        text(c, card.name, x + 6, y + 17, hand ? 10 : 9, Color.WHITE);
        text(c, "ATK " + card.attack, x + 6, y + ch - 20, 9, 0xFFDCE7EF);
        text(c, "DEF " + card.defense, x + 6, y + ch - 7, 9, 0xFFDCE7EF);
        if (game.selected == card) round(c, x + 2, y + 2, x + cw - 2, y + ch - 2, 0x0033A6FF, 0xFFE0B44C);
    }

    private void slot(Canvas c, float x, float y, float cw, float ch) {
        round(c, x, y, x + cw, y + ch, 0x25141F2A, 0x557C8EA3);
    }

    private void overlay(Canvas c, float l, float t, float r, float b, int color) {
        p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRect(l, t, r, b, p);
    }

    private void round(Canvas c, float l, float t, float r, float b, int fill, int edge) {
        p.setColor(fill); p.setStyle(Paint.Style.FILL); c.drawRoundRect(new RectF(l,t,r,b), 8,8,p);
        stroke.setColor(edge); stroke.setStyle(Paint.Style.STROKE); c.drawRoundRect(new RectF(l,t,r,b),8,8,stroke);
    }

    private void bar(Canvas c, float l, float t, float r, float b, float ratio, int color) {
        ratio = Math.max(0f, Math.min(1f, ratio));
        round(c, l,t,r,b,0x44131C24,0x335C6B78);
        p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(new RectF(l,t,l+(r-l)*ratio,b),4,4,p);
    }

    private void text(Canvas c, String s, float x, float y, float size, int color) {
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL)); c.drawText(s,x,y,p);
    }
    private void textRight(Canvas c, String s, float x, float y, float size, int color) {
        p.setTextSize(size); float width = p.measureText(s); text(c,s,x-width,y,size,color);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) return true;
        float x=e.getX(), y=e.getY(), w=getWidth(), h=getHeight();
        if (y >= h - 60) {
            if (x < 120) { int i=handIndexAt(x,y,h); if(i>=0) game.summon(i); }
            else if (x < 225) game.battlePhase();
            else if (x < 350) game.attack();
            else if (x > w-140) game.endTurn();
            invalidate(); return true;
        }
        if (y >= h*.79f && y < h*.98f) {
            int i=handIndexAt(x,y,h); if(i>=0) game.summon(i);
        } else if (y >= h*.50f && y < h*.78f) {
            int i=(int)((x-w*.18f)/(w*.125f)); game.selectField(i);
        }
        invalidate(); return true;
    }

    private int handIndexAt(float x,float y,float h) {
        int n=Math.min(game.you.hand.size(),7); if(n==0) return -1;
        float cw=Math.min(getWidth()*.095f,105f), gap=Math.min(cw*.52f,42f), total=cw+(n-1)*gap, start=(getWidth()-total)/2f;
        int i=Math.round((x-start)/gap); return i>=0&&i<n?i:-1;
    }
}
