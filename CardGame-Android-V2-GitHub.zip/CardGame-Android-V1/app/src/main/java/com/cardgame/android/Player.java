package com.cardgame.android;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Player {
    public final String name;
    public int lp = 8000;
    public final List<Card> deck = new ArrayList<>();
    public final List<Card> hand = new ArrayList<>();
    public final List<Card> field = new ArrayList<>();
    public final List<Card> graveyard = new ArrayList<>();
    public boolean summoned;

    public Player(String name) {
        this.name = name;
    }

    public void shuffle() {
        Collections.shuffle(deck);
    }

    public void draw() {
        if (!deck.isEmpty()) hand.add(deck.remove(deck.size() - 1));
    }

    public void damage(int amount) {
        lp = Math.max(0, lp - amount);
    }
}
