package com.cardgame.android;

public final class Card {
    public final String name;
    public final int attack;
    public final int defense;
    public final Effect effect;

    public Card(String name, int attack, int defense, Effect effect) {
        this.name = name;
        this.attack = attack;
        this.defense = defense;
        this.effect = effect;
    }
}
