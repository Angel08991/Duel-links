package com.cardgame.android;

import java.util.ArrayList;
import java.util.List;

public final class DuelEngine {
    public enum Phase { DRAW, MAIN, BATTLE, END }

    public final Player you = new Player("You");
    public final Player ai = new Player("AI");
    public Phase phase = Phase.MAIN;
    public boolean yourTurn = true;
    public boolean gameOver = false;
    public Card selected;
    public String message = "Choose a card from your hand.";

    public DuelEngine() {
        buildDeck(you, false);
        buildDeck(ai, true);
        you.shuffle();
        ai.shuffle();
        for (int i = 0; i < 4; i++) {
            you.draw();
            ai.draw();
        }
    }

    private void buildDeck(Player p, boolean enemy) {
        for (int i = 0; i < 3; i++) p.deck.add(new Card(
                enemy ? "Stone Brute" : "Flame Guardian", enemy ? 2000 : 1800,
                enemy ? 1000 : 1200, Effect.NONE));
        for (int i = 0; i < 3; i++) p.deck.add(new Card(
                "Forest Scout", 1200, 1600, Effect.DRAW_ONE));
        for (int i = 0; i < 2; i++) p.deck.add(new Card(
                "Spark Mage", 1500, 1000, Effect.DAMAGE_300));
        for (int i = 0; i < 2; i++) p.deck.add(new Card(
                "Stone Brute", 2000, 1000, Effect.NONE));
    }

    public void summon(int index) {
        if (!yourTurn || phase != Phase.MAIN || you.summoned || index < 0 || index >= you.hand.size()) {
            message = "No puedes invocar ahora.";
            return;
        }
        Card c = you.hand.remove(index);
        you.field.add(c);
        you.summoned = true;
        selected = c;
        resolve(c, you, ai);
        message = "Invocaste " + c.name + ".";
    }

    private void resolve(Card c, Player owner, Player enemy) {
        if (c.effect == Effect.DRAW_ONE) owner.draw();
        if (c.effect == Effect.DAMAGE_300) enemy.damage(300);
        checkWin();
    }

    public void battlePhase() {
        if (!yourTurn || phase != Phase.MAIN) return;
        phase = Phase.BATTLE;
        message = "Selecciona un monstruo y pulsa ATACAR.";
    }

    public void selectField(int index) {
        if (index >= 0 && index < you.field.size()) selected = you.field.get(index);
    }

    public void attack() {
        if (!yourTurn || phase != Phase.BATTLE || selected == null || !you.field.contains(selected)) {
            message = "Selecciona un atacante válido.";
            return;
        }

        if (ai.field.isEmpty()) {
            ai.damage(selected.attack);
            message = selected.name + " hizo " + selected.attack + " de daño directo.";
        } else {
            Card target = ai.field.get(0);
            if (selected.attack >= target.attack) {
                int damage = selected.attack - target.attack;
                ai.field.remove(target);
                ai.graveyard.add(target);
                ai.damage(damage);
                message = selected.name + " destruyó " + target.name + ".";
            } else {
                int damage = target.attack - selected.attack;
                you.field.remove(selected);
                you.graveyard.add(selected);
                you.damage(damage);
                message = selected.name + " fue destruido.";
            }
        }
        selected = null;
        checkWin();
    }

    public void endTurn() {
        if (!yourTurn || gameOver) return;
        yourTurn = false;
        phase = Phase.END;
        aiTurn();
        if (!gameOver) {
            yourTurn = true;
            you.summoned = false;
            phase = Phase.DRAW;
            you.draw();
            phase = Phase.MAIN;
            message = "Tu turno. Robaste una carta.";
        }
    }

    private void aiTurn() {
        ai.summoned = false;
        ai.draw();
        phase = Phase.MAIN;
        if (!ai.hand.isEmpty()) {
            Card c = ai.hand.remove(0);
            ai.field.add(c);
            ai.summoned = true;
            resolve(c, ai, you);
        }
        if (!ai.field.isEmpty() && !gameOver) {
            Card attacker = ai.field.get(0);
            if (you.field.isEmpty()) {
                you.damage(attacker.attack);
                message = "La IA atacó directamente por " + attacker.attack + ".";
            } else {
                Card target = you.field.get(0);
                if (attacker.attack >= target.attack) {
                    you.field.remove(target);
                    you.graveyard.add(target);
                    you.damage(attacker.attack - target.attack);
                } else {
                    ai.field.remove(attacker);
                    ai.graveyard.add(attacker);
                    ai.damage(target.attack - attacker.attack);
                }
            }
            checkWin();
        }
    }

    private void checkWin() {
        if (you.lp <= 0 || ai.lp <= 0) {
            gameOver = true;
            message = you.lp > 0 ? "¡VICTORIA!" : "DERROTA";
        }
    }
}
