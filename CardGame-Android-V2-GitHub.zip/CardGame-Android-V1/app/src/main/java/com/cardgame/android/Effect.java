package com.cardgame.android;

public enum Effect {
    NONE,
    DRAW_ONE,
    DAMAGE_300
}
