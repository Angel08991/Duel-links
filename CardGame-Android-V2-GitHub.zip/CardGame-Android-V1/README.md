# CardGame Android V2

V2 del simulador de cartas para Android. La interfaz usa una capa visual de campo y texturas proporcionadas por el usuario, con una presentación inspirada en simuladores de duelo.

## V2 incluye
- Campo de duelo horizontal para Android.
- Zonas de monstruos para ambos jugadores.
- Mano superpuesta estilo simulador.
- Deck y GY visuales.
- LP y barras de vida.
- Fases Draw / Main / Battle / End.
- Selección de monstruos y ataque.
- Indicadores visuales de selección y acciones.
- Texturas incluidas desde `edopro_textures.zip`.

## Compilación
El workflow de GitHub Actions puede compilar este proyecto sin Android Studio ni Android SDK en el teléfono.

## Nota de recursos
Las texturas de terceros deben conservarse y usarse únicamente de acuerdo con sus licencias y permisos. Esta V2 no incluye el motor ni el código de EDOPro.
