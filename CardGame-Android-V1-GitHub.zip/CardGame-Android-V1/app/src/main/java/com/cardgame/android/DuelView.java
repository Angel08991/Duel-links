package com.cardgame.android;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public final class DuelView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DuelEngine game = new DuelEngine();

    public DuelView(Context context) {
        super(context);
        paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
        setKeepScreenOn(true);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();

        c.drawColor(android.graphics.Color.rgb(18, 24, 32));

        paint.setTextSize(28);
        paint.setColor(android.graphics.Color.WHITE);
        c.drawText("CARDGAME V1", 24, 36, paint);
        paint.setTextSize(22);
        c.drawText("AI LP: " + game.ai.lp, w - 190, 34, paint);
        c.drawText("TU LP: " + game.you.lp, w - 190, h - 24, paint);

        drawZone(c, 24, 55, w - 24, h * .42f, "CAMPO DE LA IA", game.ai.field);
        drawZone(c, 24, h * .48f, w - 24, h * .72f, "TU CAMPO", game.you.field);
        drawHand(c, w, h);

        paint.setTextSize(20);
        paint.setColor(android.graphics.Color.YELLOW);
        c.drawText(game.message, 24, h * .465f, paint);

        button(c, 24, h - 105, 150, h - 45, "SUMMON");
        button(c, 160, h - 105, 300, h - 45, "BATTLE");
        button(c, 310, h - 105, 450, h - 45, "ATACAR");
        button(c, w - 170, h - 105, w - 24, h - 45, "TERMINAR");
    }

    private void drawZone(Canvas c, float l, float t, float r, float b, String title, java.util.List<Card> cards) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(android.graphics.Color.GRAY);
        c.drawRect(l, t, r, b, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(18);
        c.drawText(title, l + 8, t + 22, paint);
        float x = l + 10;
        for (Card card : cards) {
            card(c, card, x, t + 32, 110, 105);
            x += 120;
            if (x + 110 > r) break;
        }
    }

    private void drawHand(Canvas c, float w, float h) {
        float x = 24;
        for (Card card : game.you.hand) {
            card(c, card, x, h * .75f, 92, 100);
            x += 100;
            if (x + 92 > w - 190) break;
        }
    }

    private void card(Canvas c, Card card, float x, float y, float cw, float ch) {
        paint.setColor(android.graphics.Color.rgb(48, 62, 78));
        c.drawRoundRect(new RectF(x, y, x + cw, y + ch), 10, 10, paint);
        paint.setColor(android.graphics.Color.WHITE);
        paint.setTextSize(13);
        c.drawText(card.name, x + 5, y + 18, paint);
        c.drawText(card.attack + " ATK", x + 5, y + ch - 24, paint);
        c.drawText(card.defense + " DEF", x + 5, y + ch - 7, paint);
    }

    private void button(Canvas c, float l, float t, float r, float b, String text) {
        paint.setColor(android.graphics.Color.rgb(55, 90, 125));
        c.drawRoundRect(new RectF(l, t, r, b), 10, 10, paint);
        paint.setColor(android.graphics.Color.WHITE);
        paint.setTextSize(17);
        c.drawText(text, l + 12, t + 38, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) return true;

        float x = e.getX(), y = e.getY(), h = getHeight(), w = getWidth();

        if (y >= h - 105 && y <= h - 45) {
            if (x < 150) {
                int index = handIndexAt(x, y, h);
                if (index >= 0) game.summon(index);
            } else if (x < 300) {
                game.battlePhase();
            } else if (x < 450) {
                game.attack();
            } else if (x > w - 170) {
                game.endTurn();
            }
            invalidate();
            return true;
        }

        if (y >= h * .75f && y < h - 110) {
            int index = handIndexAt(x, y, h);
            if (index >= 0) game.summon(index);
        }

        if (y >= h * .48f && y < h * .72f) {
            int index = (int)((x - 34) / 120);
            game.selectField(index);
        }

        invalidate();
        return true;
    }

    private int handIndexAt(float x, float y, float h) {
        if (x < 24 || y < h * .75f) return -1;
        return (int)((x - 24) / 100);
    }
}
