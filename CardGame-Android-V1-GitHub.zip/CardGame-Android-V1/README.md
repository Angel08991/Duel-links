# CardGame Android V1

Proyecto Android nativo para un juego de cartas original.

## Compilación sin PC

Este repositorio está preparado para compilar en GitHub Actions. No necesitas Android Studio, Android SDK ni Gradle en el teléfono.

El workflow instala Java 17, Android SDK y Gradle 8.10.2 en el runner de GitHub, extrae `CardGame-Android-V1.zip` y genera el APK.

## Estructura

- `app/` — aplicación Android.
- `app/src/main/java/com/cardgame/android/` — motor y UI.
- `app/src/main/res/` — recursos Android.
- `build.gradle` — configuración Android.
- `settings.gradle` — configuración Gradle.

## Build

En GitHub: Actions → Build Android APK → Run workflow.

El APK aparece en Artifacts como `CardGame-debug-apk`.
